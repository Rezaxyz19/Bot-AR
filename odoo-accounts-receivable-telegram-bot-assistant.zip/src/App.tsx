/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  Database,
  Send,
  AlertCircle,
  CheckCircle2,
  Settings,
  Sparkles,
  Copy,
  RefreshCw,
  TrendingUp,
  User,
  HelpCircle,
  FileText,
  Lock,
  Eye,
  EyeOff,
  Terminal,
  Activity,
  Check,
  CreditCard,
  CheckSquare
} from 'lucide-react';
import { OdooInvoice, BotLog, TelegramCommand } from './types';

export default function App() {
  // Config state
  const [odooUrl, setOdooUrl] = useState('');
  const [odooDb, setOdooDb] = useState('');
  const [odooUsername, setOdooUsername] = useState('');
  const [odooApiKey, setOdooApiKey] = useState('');
  const [telegramToken, setTelegramToken] = useState('');
  const [telegramChatId, setTelegramChatId] = useState('');
  const [simulationMode, setSimulationMode] = useState(true);

  // Verification & loading states
  const [isVerifyingOdoo, setIsVerifyingOdoo] = useState(false);
  const [odooStatus, setOdooStatus] = useState<'untested' | 'connected' | 'failed'>('untested');
  const [odooError, setOdooError] = useState('');
  
  const [isRegisteringWebhook, setIsRegisteringWebhook] = useState(false);
  const [telegramStatus, setTelegramStatus] = useState<'untested' | 'connected' | 'failed'>('untested');
  const [telegramError, setTelegramError] = useState('');

  // App Data states
  const [invoices, setInvoices] = useState<OdooInvoice[]>([]);
  const [isLoadingInvoices, setIsLoadingInvoices] = useState(false);
  const [invoiceError, setInvoiceError] = useState('');
  
  const [botLogs, setBotLogs] = useState<BotLog[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);

  // Interactive UI panel states
  const [showSettings, setShowSettings] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const [showBotToken, setShowBotToken] = useState(false);
  
  // Custom draft helper state
  const [selectedInvoice, setSelectedInvoice] = useState<OdooInvoice | null>(null);
  const [draftTone, setDraftTone] = useState('Sopan, Ramah, & Profesional');
  const [generatedDraft, setGeneratedDraft] = useState('');
  const [isGeneratingDraft, setIsGeneratingDraft] = useState(false);
  const [copiedDraft, setCopiedDraft] = useState(false);

  // Simulation Chat states
  const [chatMessage, setChatMessage] = useState('');
  const [isChatSending, setIsChatSending] = useState(false);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Active commands metadata list
  const commands: TelegramCommand[] = [
    {
      command: '/start',
      description: 'Menyapa bot & memunculkan instruksi sapaan awal',
      useCase: 'Inisialisasi bot pertama kali'
    },
    {
      command: '/summary',
      description: 'Rangkuman ringkas sisa saldo AR & status jatuh tempo',
      useCase: 'Pantauan harian AR supervisor'
    },
    {
      command: '/outstanding',
      description: 'Menampilkan list seluruh invoice Odoo yang belum lunas',
      useCase: 'Melihat histori piutang aktif'
    },
    {
      command: '/overdue',
      description: 'Daftar invoice yang terlambat melewati tanggal jatuh tempo',
      useCase: 'Prioritas follow-up harian'
    },
    {
      command: '/aging',
      description: 'Ar-Aging Analisis (0-30 Hari, 30-60, 60-90, 90+ Hari)',
      useCase: 'Laporan audit umur piutang'
    },
    {
      command: '/customer',
      description: 'Mengelompokkan sisa piutang berdasar nama customer',
      useCase: 'Menilai risiko kredit per mitra usaha'
    },
    {
      command: '/remind [nama]',
      description: 'Membuat draf pesan WA/Telegram ramah otomatis via Gemini AI',
      parameters: 'Nama pelanggan (parsial)',
      useCase: 'Menyusun draf pengingat bayar instan'
    }
  ];

  // Load config & data on mount
  useEffect(() => {
    // Sync credentials from endpoint or localStorage
    fetch('/api/config')
      .then((res) => res.json())
      .then((data) => {
        if (data.odoo) {
          setOdooUrl(data.odoo.url || '');
          setOdooDb(data.odoo.db || '');
          setOdooUsername(data.odoo.username || '');
          setOdooApiKey(data.odoo.apiKey || '');
        }
        if (data.telegram) {
          setTelegramToken(data.telegram.botToken || '');
          setTelegramChatId(data.telegram.chatId || '');
        }
        setSimulationMode(data.simulationMode ?? true);
        
        // Initial fetch of data
        loadInvoices(data.simulationMode ?? true, data.odoo);
        loadLogs();
      })
      .catch((err) => console.error('Gagal mengambil konfigurasi awal:', err));
  }, []);

  // Scroll simulation chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [botLogs]);

  const loadInvoices = async (isSim: boolean, odooCreds?: any) => {
    setIsLoadingInvoices(true);
    setInvoiceError('');
    try {
      const creds = odooCreds || { url: odooUrl, db: odooDb, username: odooUsername, apiKey: odooApiKey };
      const response = await fetch('/api/odoo/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          simulationMode: isSim,
          odoo: creds
        })
      });
      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || 'Gagal memuat invoice');
      }
      const data = await response.json();
      setInvoices(data);
      if (data.length > 0 && !selectedInvoice) {
        setSelectedInvoice(data[0]);
      }
    } catch (error: any) {
      console.error(error);
      setInvoiceError(error.message);
    } finally {
      setIsLoadingInvoices(false);
    }
  };

  const loadLogs = async () => {
    setIsLoadingLogs(true);
    try {
      const res = await fetch('/api/bot/logs');
      const data = await res.json();
      setBotLogs(data);
    } catch (e) {
      console.error('Gagal mengambil log bot:', e);
    } finally {
      setIsLoadingLogs(false);
    }
  };

  const handleSaveConfig = async (overrideSim?: boolean) => {
    const nextSim = overrideSim !== undefined ? overrideSim : simulationMode;
    const body = {
      odoo: { url: odooUrl, db: odooDb, username: odooUsername, apiKey: odooApiKey },
      telegram: { botToken: telegramToken, chatId: telegramChatId, isActive: !!telegramToken },
      simulationMode: nextSim
    };

    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      setSimulationMode(data.config.simulationMode);
      // Reload on config write
      loadInvoices(data.config.simulationMode, data.config.odoo);
      loadLogs();
    } catch (err) {
      console.error('Gagal menyimpan konfigurasi server:', err);
    }
  };

  const handleVerifyOdoo = async () => {
    setIsVerifyingOdoo(true);
    setOdooStatus('untested');
    setOdooError('');
    try {
      const res = await fetch('/api/odoo/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: odooUrl,
          db: odooDb,
          username: odooUsername,
          apiKey: odooApiKey
        })
      });
      const data = await res.json();
      if (data.success) {
        setOdooStatus('connected');
        // If success, automatically turn off simulation mode
        setSimulationMode(false);
        handleSaveConfig(false);
      } else {
        setOdooStatus('failed');
        setOdooError(data.error || 'Autentikasi gagal.');
      }
    } catch (error: any) {
      setOdooStatus('failed');
      setOdooError(error.message || 'Koneksi gagal.');
    } finally {
      setIsVerifyingOdoo(false);
    }
  };

  const handleRegisterWebhook = async () => {
    if (!telegramToken) {
      alert('Masukkan Token Bot Telegram terlebih dahulu!');
      return;
    }
    setIsRegisteringWebhook(true);
    setTelegramStatus('untested');
    setTelegramError('');
    try {
      const res = await fetch('/api/telegram/register-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ botToken: telegramToken })
      });
      const data = await res.json();
      if (data.success) {
        setTelegramStatus('connected');
        alert(`Webhook sukses terdaftar di Telegram!\nURL Webhook: ${data.webhookUrl}`);
        handleSaveConfig();
      } else {
        setTelegramStatus('failed');
        setTelegramError(data.error || 'Gagal meregistrasikan webhook.');
      }
    } catch (error: any) {
      setTelegramStatus('failed');
      setTelegramError(error.message || 'Error koneksi API Telegram');
    } finally {
      setIsRegisteringWebhook(false);
    }
  };

  const handleSendTestMessage = async () => {
    if (!telegramToken || !telegramChatId) {
      alert('Masukkan Bot Token dan Chat ID Anda terlebih dahulu!');
      return;
    }
    try {
      const res = await fetch('/api/telegram/send-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          botToken: telegramToken,
          chatId: telegramChatId,
          message: '🔔 <b>TES VALIDASI KONEKSI</b>\n\nSelamat! Koneksi Telegram Bot Anda untuk Accounts Receivable (AR) telah aktif dan terhubung ke dashboard Anda.'
        })
      });
      if (res.ok) {
        alert('Pesan tes dikirim! Cek chat Telegram Anda.');
        loadLogs();
      } else {
        const err = await res.json();
        alert(`Gagal mengirim tes: ${err.error}`);
      }
    } catch (e: any) {
      alert(`Koneksi error: ${e.message}`);
    }
  };

  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;

    const userText = chatMessage;
    setChatMessage('');
    setIsChatSending(true);

    try {
      const response = await fetch('/api/telegram/sandbox-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: userText, username: 'User (Sandbox)' })
      });
      if (response.ok) {
        await loadLogs();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsChatSending(false);
    }
  };

  const clearLogs = async () => {
    if (confirm('Apakah Anda yakin ingin menghapus histori aktivitas log bot?')) {
      await fetch('/api/bot/clear-logs', { method: 'POST' });
      loadLogs();
    }
  };

  const generateAIDraft = async () => {
    if (!selectedInvoice) return;
    setIsGeneratingDraft(true);
    setGeneratedDraft('');
    setCopiedDraft(false);

    // Group multiple invoices from same customer if exists
    const customerInvs = invoices.filter(
      (inv) => inv.customerName === selectedInvoice.customerName && inv.status !== 'paid'
    );

    // Dynamic fast local template compiler (Instant, secure, zero network request)
    setTimeout(() => {
      const unpaidInvoicesText = customerInvs.map((inv) => 
        `- Invoice ${inv.number} (Jatuh tempo: ${inv.dueDate}, Sisa: ${formatRupiah(inv.amountResidual)})`
      ).join('\n');

      const totalOutstanding = customerInvs.reduce((sum, inv) => sum + inv.amountResidual, 0);
      const totalFormatted = formatRupiah(totalOutstanding);

      const cleanTone = (draftTone || '').toLowerCase();
      let draftText = '';

      if (cleanTone.includes('tegas') || cleanTone.includes('overdue')) {
        draftText = `Kepada Yth. Pimpinan / Tim Finance *${selectedInvoice.customerName}*,\n\n` +
          `Menindaklanjuti catatan keuangan kami, bersama pesan ini kami sampaikan pemberitahuan penting mengenai adanya tagihan yang telah melewati hari jatuh tempo pembayaran (Overdue).\n\n` +
          `Berikut adalah rincian tagihan overdue yang membutuhkan perhatian mendesak Anda:\n` +
          `${unpaidInvoicesText}\n\n` +
          `*Total Tunggakan:* *${totalFormatted}*\n\n` +
          `Mengenal umur tagihan yang sudah cukup lama, mohon masukan/prioritas dari Bapak/Ibu untuk segera melunasi kewajiban tagihan di atas demi menjaga kesinambungan kerja sama bisnis dan kredit yang baik.\n\n` +
          `Mohon selesaikan pelunasan ke rekening resmi korporat kami:\n` +
          `🏦 *Bank Mandiri*\n` +
          `📌 *No. Rekening:* 123-456-7890-50\n` +
          `📌 *Atas Nama:* PT Solusi Integrasi ERP\n\n` +
          `Harap konfirmasi segera kepada kami jika Anda sudah melakukan pembayaran dengan melampirkan salinan bukti transfer keuangan.\n\n` +
          `Apabila ada kendala pembayaran atau kebutuhan pencocokan data saldo piutang, segera hubungi penanggung jawab kami:\n` +
          `📞 *Staff AR:* 0812-3456-7890\n\n` +
          `Kami sangat menghargai perhatian cepat dan kerja sama kooperatif dari Anda dalam menyelesaikan hal ini.\n\n` +
          `Hormat kami,\n` +
          `*Divisi Accounts Receivable*\n` +
          `*PT Solusi Integrasi ERP*`;
      } else if (cleanTone.includes('kasual') || cleanTone.includes('akrab')) {
        draftText = `Halo Kak *${selectedInvoice.customerName}*, Apa kabar? Semoga beraktivitas dengan lancar hari ini ya! 😊\n\n` +
          `Kak, kami mau mengonfirmasi titipan tagihan bulanan nih untuk transaksi invoice yang kemarin dipesan. Biar pembukuan kita sama-sama rapi, berikut rincian sisa tagihannya ya:\n\n` +
          `${unpaidInvoicesText}\n\n` +
          `*Total outstanding:* *${totalFormatted}*\n\n` +
          `Kalau sekiranya sudah dijadwalkan bayar, boleh langsung dikirim ke rekening Mandiri kita ya Kak:\n` +
          `🏦 *Bank Mandiri*\n` +
          `📌 *No. Rekening:* 123-456-7890-50\n` +
          `📌 *A/N:* PT Solusi Integrasi ERP\n\n` +
          `Kalau Kakak sudah transfer, jangan lupa info/send bukti transfernya ke kita ya biar bisa langsung kita update lunas di sistem Odoo kita. 👍\n\n` +
          `Jika ada kendala pembayaran atau sekadar mau tanya rincian belanjaan, kontak tim AR kita aja di:\n` +
          `📞 *Staff AR:* 0812-3456-7890 (atau reply chat ini)\n\n` +
          `Makasih banyak atas bantuannya ya Kak! Sehat selalu dan sukses buat usahanya. 🙏 Kak!`;
      } else if (cleanTone.includes('english') || cleanTone.includes('formal')) {
        draftText = `Dear Finance Team at *${selectedInvoice.customerName}*,\n\n` +
          `I hope this message finds you well.\n\n` +
          `We are writing from the *Accounts Receivable (AR) department of PT Solusi Integrasi ERP* to kindly request an update regarding the outstanding invoices on your account.\n\n` +
          `According to our records, the following invoices remain unpaid:\n` +
          `${unpaidInvoicesText}\n\n` +
          `*Total Outstanding Balance:* *${totalFormatted}*\n\n` +
          `Please kindly arrange for the settlement of these entries to ensure your account remains in good standing.\n\n` +
          `Payments can be wired directly to our official company bank account:\n` +
          `🏦 *Bank Mandiri*\n` +
          `📌 *Account Number:* 123-456-7890-50\n` +
          `📌 *Beneficiary Name:* PT Solusi Integrasi ERP\n\n` +
          `Once the payment is processed, please send us a copy of the bank transfer advice for swift allocation and matching in our ERP ledger.\n\n` +
          `Should you require any documentation (e.g., e-invoices, tax papers) or have any questions, feel free to contact our AR Helpdesk:\n` +
          `📞 *AR Specialist:* +62 812-3456-7890\n\n` +
          `We deeply appreciate your prompt attention and continuous partnership.\n\n` +
          `Best regards,\n` +
          `*Finance & Accounts Receivable Team*\n` +
          `*PT Solusi Integrasi ERP*`;
      } else {
        // Sopan, Ramah, & Profesional (Default)
        draftText = `Halo Bapak/Ibu Finance *${selectedInvoice.customerName}*,\n\n` +
          `Semoga Bapak/Ibu selalu sehat dan sukses dalam segala usaha. 🙏\n\n` +
          `Kami dari tim *Accounts Receivable (AR) PT Solusi Integrasi ERP* ingin mengonfirmasi dan mengingatkan kembali perihal tagihan berjalan yang masih outstanding (belum lunas) pada sistem kami.\n\n` +
          `Berikut adalah rincian invoice yang belum terselesaikan:\n` +
          `${unpaidInvoicesText}\n\n` +
          `*Total Outstanding:* *${totalFormatted}*\n\n` +
          `Kami mohon kesediaan Bapak/Ibu untuk menjadwalkan pembayaran tagihan tersebut demi kelancaran rekonsiliasi data keuangan antar-perusahaan.\n\n` +
          `Pembayaran dapat ditransfer ke rekening resmi kami:\n` +
          `🏦 *Bank Mandiri*\n` +
          `📌 *No. Rekening:* 123-456-7890-50\n` +
          `📌 *Atas Nama (A/N):* PT Solusi Integrasi ERP\n\n` +
          `Setelah transfer berhasil dilakukan, mohon kirimkan bukti transfer tersebut demi kemandirian alokasi dana tagihan Anda.\n\n` +
          `Jika ada hal yang ingin ditanyakan atau membutuhkan rekonsiliasi/pencocokan data (faktur pajak, dll.), silakan menghubungi kontak person administrasi AR kami:\n` +
          `📞 *Staff AR:* 0812-3456-7890\n\n` +
          `Terima kasih banyak atas kerja sama yang baik dan pengertian Bapak/Ibu selama ini.\n\n` +
          `Salam hangat,\n` +
          `*Tim Finance & AR*\n` +
          `*PT Solusi Integrasi ERP*`;
      }

      setGeneratedDraft(draftText);
      setIsGeneratingDraft(false);
    }, 150);
  };

  // Quick prompt generator triggers automatically when selected invoice changes
  useEffect(() => {
    if (selectedInvoice) {
      generateAIDraft();
    }
  }, [selectedInvoice, draftTone]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedDraft);
    setCopiedDraft(true);
    setTimeout(() => setCopiedDraft(false), 2000);
  };

  // Calculations for Dashboard Metrics
  const totalReceivables = invoices.reduce((sum, inv) => sum + inv.amountResidual, 0);
  const overdueInvoices = invoices.filter((inv) => inv.status === 'overdue');
  const totalOverdue = overdueInvoices.reduce((sum, inv) => sum + inv.amountResidual, 0);
  const paidInvoices = invoices.filter((inv) => inv.status === 'paid');
  const countOutstanding = invoices.filter((inv) => inv.amountResidual > 0).length;

  // Aging categories for visual bar
  let age0_30 = 0;
  let age31_60 = 0;
  let age61_90 = 0;
  let age90_plus = 0;

  invoices.forEach((inv) => {
    if (inv.amountResidual <= 0) return;
    if (inv.daysOverdue <= 30) age0_30 += inv.amountResidual;
    else if (inv.daysOverdue <= 60) age31_60 += inv.amountResidual;
    else if (inv.daysOverdue <= 90) age61_90 += inv.amountResidual;
    else age90_plus += inv.amountResidual;
  });

  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Background Ambience Dots */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#0f172a_1px,transparent_1px),linear-gradient(to_bottom,#0f172a_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none opacity-40"></div>

      {/* HEADER BAR */}
      <header className="relative border-b border-slate-800 bg-slate-900/60 backdrop-blur-md px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4 z-10">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-600/20 text-indigo-400 rounded-xl border border-indigo-500/20 shadow-indigo-500/10 shadow-lg">
            <Bot className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              Odoo Accounting Telegram Bot
              <span className="text-xs bg-indigo-500/15 text-indigo-400 border border-indigo-500/20 px-2 py-0.5 rounded-full font-medium">Asisten AR Staff</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">Pantau piutang Odoo ERP, kelola automasi Telegram bot, & draf penagihan otomatis bertenaga Gemini AI</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Simulation Toggle Badge */}
          <button
            onClick={() => {
              const nextMode = !simulationMode;
              setSimulationMode(nextMode);
              handleSaveConfig(nextMode);
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
              simulationMode
                ? 'bg-amber-500/10 text-amber-400 border-amber-500/20 hover:bg-amber-500/20 shadow-amber-500/5 shadow-md'
                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/20 shadow-emerald-500/5 shadow-md'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            Mode: {simulationMode ? 'Simulasi Data' : 'Riil Odoo ERP'}
          </button>

          {/* Settings Trigger */}
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg border transition duration-200 ${
              showSettings 
                ? 'bg-slate-800 border-slate-600 text-white' 
                : 'bg-indigo-600 border-indigo-500 text-white hover:bg-indigo-500 shadow-indigo-500/20 shadow-lg'
            }`}
          >
            <Settings className="w-4 h-4" />
            Konfigurasi Integrasi
          </button>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 md:px-6 py-6 space-y-6 relative z-10">

        {/* INTEGRATION SETTINGS PANEL (COLLAPSIBLE DRAWER IN PAGE) */}
        {showSettings && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden transition-all duration-300">
            <div className="absolute top-0 right-0 p-8 w-64 h-64 bg-indigo-500/5 rounded-full filter blur-3xl pointer-events-none"></div>
            
            <div className="flex justify-between items-start border-b border-slate-800 pb-4 mb-5">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Settings className="w-4.5 h-4.5 text-indigo-400" />
                  Pengaturan Kredensial & Integrasi
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Konfigurasikan detail akses Odoo ERP dan Token Telegram Anda di sini untuk menghubungkan bot asli Anda.
                </p>
              </div>
              <button 
                onClick={() => setShowSettings(false)}
                className="text-xs text-slate-400 hover:text-white underline cursor-pointer"
              >
                Tutup Panel
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* ODOO SETTINGS */}
              <div className="bg-slate-950/50 rounded-xl p-5 border border-slate-800/80 space-y-4">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-800 pb-2">
                  <Database className="w-4 h-4 text-indigo-400" />
                  Koneksi Odoo Accounting API
                </h3>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-slate-400 font-medium mb-1">Odoo Base URL</label>
                    <input
                      type="text"
                      value={odooUrl}
                      onChange={(e) => setOdooUrl(e.target.value)}
                      placeholder="e.g. https://my-company.odoo.com"
                      className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-400 font-medium mb-1">Odoo Database</label>
                      <input
                        type="text"
                        value={odooDb}
                        onChange={(e) => setOdooDb(e.target.value)}
                        placeholder="e.g. odoo-production"
                        className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 font-medium mb-1">Username / Email</label>
                      <input
                        type="text"
                        value={odooUsername}
                        onChange={(e) => setOdooUsername(e.target.value)}
                        placeholder="staff-ar@company.com"
                        className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 font-medium mb-1 flex justify-between items-center">
                      <span>Password / Odoo Developer API Key</span>
                      <button 
                        type="button" 
                        onClick={() => setShowApiKey(!showApiKey)}
                        className="text-[10px] text-indigo-400 hover:underline flex items-center gap-1 focus:outline-none"
                      >
                        {showApiKey ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        {showApiKey ? 'Sembunyikan' : 'Lihat'}
                      </button>
                    </label>
                    <input
                      type={showApiKey ? 'text' : 'password'}
                      value={odooApiKey}
                      onChange={(e) => setOdooApiKey(e.target.value)}
                      placeholder="Masukkan Password Odoo Anda"
                      className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-between gap-3">
                    <button
                      type="button"
                      onClick={handleVerifyOdoo}
                      disabled={isVerifyingOdoo || !odooUrl}
                      className="bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-600/30 font-semibold px-4 py-1.5 rounded-lg text-xs transition duration-200 disabled:opacity-40"
                    >
                      {isVerifyingOdoo ? 'Mencoba Koneksi...' : 'Uji Koneksi Odoo'}
                    </button>

                    {odooStatus === 'connected' && (
                      <span className="text-xs text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Terkoneksi
                      </span>
                    )}
                    {odooStatus === 'failed' && (
                      <span className="text-xs text-rose-400 flex items-center gap-1 bg-rose-500/10 px-2 py-1 rounded border border-rose-500/20 select-none">
                        ⚠️ Gagal
                      </span>
                    )}
                  </div>
                  {odooError && <p className="text-[10px] text-rose-400 bg-rose-950/20 p-2 rounded border border-rose-900/30">{odooError}</p>}
                </div>
              </div>

              {/* TELEGRAM SETTINGS */}
              <div className="bg-slate-950/50 rounded-xl p-5 border border-slate-800/80 space-y-4">
                <h3 className="text-sm font-semibold text-white flex items-center gap-2 border-b border-slate-800 pb-2">
                  <Bot className="w-4 h-4 text-indigo-400" />
                  Bot Telegram Anda
                </h3>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-slate-400 font-medium mb-1 flex justify-between items-center">
                      <span>Telegram Bot Token</span>
                      <button 
                        type="button" 
                        onClick={() => setShowBotToken(!showBotToken)}
                        className="text-[10px] text-indigo-400 hover:underline flex items-center gap-1 focus:outline-none"
                      >
                        {showBotToken ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        {showBotToken ? 'Sembunyikan' : 'Lihat'}
                      </button>
                    </label>
                    <input
                      type={showBotToken ? 'text' : 'password'}
                      value={telegramToken}
                      onChange={(e) => setTelegramToken(e.target.value)}
                      placeholder="e.g. 123456789:ABCdefGhIJKlmNoPQRsTUVwXyZ"
                      className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 font-medium mb-1">Telegram Chat ID / Group ID</label>
                    <input
                      type="text"
                      value={telegramChatId}
                      onChange={(e) => setTelegramChatId(e.target.value)}
                      placeholder="e.g. 987654321 atau -100123456789 (untuk grup)"
                      className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                    <span className="text-[10px] text-slate-400 block mt-1">
                      Kirim pesan apa saja ke bot Anda, lalu buat bot membalas ke Chat ID khusus ini.
                    </span>
                  </div>

                  <div className="pt-2 flex flex-wrap items-center gap-2 justify-between">
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={handleRegisterWebhook}
                        disabled={isRegisteringWebhook || !telegramToken}
                        className="bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-600/30 font-semibold px-4 py-1.5 rounded-lg text-xs transition duration-200 disabled:opacity-40"
                      >
                        {isRegisteringWebhook ? 'Mendaftarkan...' : 'Aktifkan Webhook Bot'}
                      </button>

                      <button
                        type="button"
                        onClick={handleSendTestMessage}
                        disabled={!telegramToken || !telegramChatId}
                        className="bg-indigo-600 border border-indigo-500 hover:bg-indigo-500 text-white font-semibold px-4 py-1.5 rounded-lg text-xs transition duration-200 disabled:opacity-40"
                      >
                        Kirim Pesan Tes
                      </button>
                    </div>

                    {telegramStatus === 'connected' && (
                      <span className="text-xs text-emerald-400 flex items-center gap-1 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Webhook Aktif
                      </span>
                    )}
                  </div>
                  {telegramError && <p className="text-[10px] text-rose-400 bg-rose-950/20 p-2 rounded border border-rose-900/30">{telegramError}</p>}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 border-t border-slate-800 pt-5 mt-5">
              <button
                onClick={() => handleSaveConfig()}
                className="bg-indigo-600 text-white font-bold text-xs px-6 py-2 rounded-lg hover:bg-indigo-500 transition shadow-lg shadow-indigo-600/20"
              >
                Simpan Konfigurasi
              </button>
            </div>
          </div>
        )}

        {/* METRICS CARD DASHBOARD GRID */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Outstanding Sales AR */}
          <div className="bg-slate-900/60 backdrop-blur-sm border border-slate-800 rounded-xl p-5 flex items-center justify-between hover:border-slate-700/80 transition shadow-md group relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 p-8 h-full bg-indigo-500 pointer-events-none group-hover:h-3/4 transition-all"></div>
            <div className="space-y-1">
              <span className="text-xs text-slate-400 font-medium">Total Piutang Aktif (AR)</span>
              <div className="text-xl font-bold tracking-tight text-white">{formatRupiah(totalReceivables)}</div>
              <p className="text-[10px] text-slate-400">Total invoice belum lunas dari Odoo</p>
            </div>
            <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/10">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>

          {/* Overdue Total Amount */}
          <div className="bg-slate-900/60 backdrop-blur-sm border border-slate-800 rounded-xl p-5 flex items-center justify-between hover:border-slate-700/80 transition shadow-md group relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 p-8 h-full bg-rose-500 pointer-events-none group-hover:h-3/4 transition-all"></div>
            <div className="space-y-1">
              <span className="text-xs text-slate-400 font-medium">Total Lewat Jatuh Tempo (Overdue)</span>
              <div className="text-xl font-bold tracking-tight text-rose-400">{formatRupiah(totalOverdue)}</div>
              <p className="text-[10px] text-slate-400">{overdueInvoices.length} invoice terlambat dibayar</p>
            </div>
            <div className="p-3 bg-rose-500/10 text-rose-400 rounded-xl border border-rose-500/10">
              <AlertCircle className="w-5 h-5" />
            </div>
          </div>

          {/* Active invoice count */}
          <div className="bg-slate-900/60 backdrop-blur-sm border border-slate-800 rounded-xl p-5 flex items-center justify-between hover:border-slate-700/80 transition shadow-md group relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 p-8 h-full bg-amber-500 pointer-events-none group-hover:h-3/4 transition-all"></div>
            <div className="space-y-1">
              <span className="text-xs text-slate-400 font-medium">Invoice Outstanding</span>
              <div className="text-xl font-bold tracking-tight text-white">{countOutstanding} <span className="text-xs font-normal text-slate-400">Bills</span></div>
              <p className="text-[10px] text-slate-400">Sedang ditindaklanjuti staff AR</p>
            </div>
            <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/10">
              <FileText className="w-5 h-5" />
            </div>
          </div>

          {/* Bot State info panel */}
          <div className="bg-slate-900/60 backdrop-blur-sm border border-slate-800 rounded-xl p-5 flex items-center justify-between hover:border-slate-700/80 transition shadow-md group relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 p-8 h-full bg-emerald-500 pointer-events-none group-hover:h-3/4 transition-all"></div>
            <div className="space-y-1">
              <span className="text-xs text-slate-400 font-medium">Konektivitas Bot Telegram</span>
              <div className="text-base font-bold tracking-tight flex items-center gap-1.5 text-emerald-400 mt-1">
                {(telegramToken && telegramChatId) ? (
                  <>
                    <CheckSquare className="w-4 h-4 text-emerald-400" />
                    Siap Beroperasi
                  </>
                ) : (
                  <>
                    <HelpCircle className="w-4 h-4 text-amber-400 animate-pulse" />
                    Butuh Konfigurasi
                  </>
                )}
              </div>
              <p className="text-[10px] text-slate-400">
                {(telegramToken && telegramChatId) ? 'Webhook & Chat ID terhubung' : 'Gunakan tombol konfigurasi'}
              </p>
            </div>
            <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/10">
              <Bot className="w-5 h-5" />
            </div>
          </div>
        </section>

        {/* WORKSPACE MIDDLE PANELS GRID */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">

          {/* LEFT: ODOO LEDGER & AGING PLOT (7 COLS) */}
          <div className="lg:col-span-7 bg-slate-900/40 border border-slate-800 rounded-2xl p-5 flex flex-col space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <Database className="w-4.5 h-4.5 text-indigo-400" />
                  Buku Piutang Pelanggan Odoo ERP
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">Daftar invoice terbit dari Odoo Accounting yang belum lunas</p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => loadInvoices(simulationMode)}
                  disabled={isLoadingInvoices}
                  className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg border border-slate-800 hover:border-slate-700 transition"
                  title="Sinkronisasi Tagihan Odoo"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoadingInvoices ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>

            {/* ERROR NOTIFICATION FOR LEDGER */}
            {invoiceError && (
              <div className="p-3 bg-rose-500/10 text-rose-400 border border-rose-500/20 rounded-xl text-xs flex flex-col gap-2">
                <span className="font-semibold flex items-center gap-1.5"><AlertCircle className="w-4 h-4" /> Gagal menarik data Odoo ERP</span>
                <p className="text-[11px] block">{invoiceError}</p>
                <div className="border-t border-rose-900/30 pt-2 flex items-center justify-between">
                  <span>Sistem otomatis beralih ke <b>Mode Simulasi</b> agar Anda dapat bermain.</span>
                  <button
                    onClick={() => {
                      setSimulationMode(true);
                      handleSaveConfig(true);
                    }}
                    className="bg-rose-500 text-white font-bold text-[10px] px-3 py-1 rounded"
                  >
                    Aktifkan Simulasi Data
                  </button>
                </div>
              </div>
            )}

            {/* ARTIFICIAL AGING CHART */}
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4.5 space-y-3 shadow-inner">
              <span className="text-xs font-semibold text-white block">Analisis Umur Piutang (AR Aging Bar)</span>
              
              <div className="flex items-center gap-1 h-3.5 w-full rounded-full overflow-hidden bg-slate-800">
                {totalReceivables > 0 ? (
                  <>
                    <div 
                      style={{ width: `${Math.max(4, ( (totalReceivables - totalOverdue) / totalReceivables) * 100)}%` }} 
                      className="bg-emerald-500 h-full hover:brightness-110 transition cursor-pointer"
                      title={`Belum Jatuh Tempo: ${formatRupiah(totalReceivables - totalOverdue)}`}
                    ></div>
                    <div 
                      style={{ width: `${Math.max(4, (age0_30 / totalReceivables) * 100)}%` }} 
                      className="bg-amber-400 h-full hover:brightness-110 transition cursor-pointer"
                      title={`Overdue 1-30 hari: ${formatRupiah(age0_30)}`}
                    ></div>
                    <div 
                      style={{ width: `${Math.max(4, (age31_60 / totalReceivables) * 100)}%` }} 
                      className="bg-amber-600 h-full hover:brightness-110 transition cursor-pointer"
                      title={`Overdue 31-60 hari: ${formatRupiah(age31_60)}`}
                    ></div>
                    <div 
                      style={{ width: `${Math.max(4, (age61_90 / totalReceivables) * 100)}%` }} 
                      className="bg-rose-500 h-full hover:brightness-110 transition cursor-pointer"
                      title={`Overdue 61-90 hari: ${formatRupiah(age61_90)}`}
                    ></div>
                    <div 
                      style={{ width: `${Math.max(4, (age90_plus / totalReceivables) * 100)}%` }} 
                      className="bg-purple-600 h-full hover:brightness-110 transition cursor-pointer"
                      title={`Overdue >90 hari: ${formatRupiah(age90_plus)}`}
                    ></div>
                  </>
                ) : (
                  <div className="w-full h-full bg-slate-800 text-slate-500 text-[10px] flex items-center justify-center">Tidak ada piutang aktif</div>
                )}
              </div>

              {/* Chart Legend */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-1">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded bg-emerald-500 shrink-0"></div>
                  <div className="text-[10px] text-slate-400 truncate">
                    Belum Jth Tempo <span className="block font-semibold text-white">{formatRupiah(totalReceivables - totalOverdue)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded bg-amber-400 shrink-0"></div>
                  <div className="text-[10px] text-slate-400 truncate">
                    1-30 Hari <span className="block font-semibold text-white">{formatRupiah(age0_30)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded bg-amber-600 shrink-0"></div>
                  <div className="text-[10px] text-slate-400 truncate">
                    31-60 Hari <span className="block font-semibold text-white">{formatRupiah(age31_60)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded bg-rose-500 shrink-0"></div>
                  <div className="text-[10px] text-slate-400 truncate">
                    61-90 Hari <span className="block font-semibold text-white">{formatRupiah(age61_90)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded bg-purple-600 shrink-0"></div>
                  <div className="text-[10px] text-slate-400 truncate">
                    &gt;90 Hari <span className="block font-semibold text-white">{formatRupiah(age90_plus)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* LEDGER INVOICE LIST */}
            <div className="flex-1 overflow-x-auto min-h-[350px]">
              {isLoadingInvoices ? (
                <div className="flex flex-col items-center justify-center h-full py-12 space-y-3">
                  <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin" />
                  <p className="text-xs text-slate-400">Menyinkronkan data invoices langsung dari Odoo...</p>
                </div>
              ) : invoices.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full py-12 text-slate-400">
                  <Database className="w-10 h-10 mb-2 opacity-35" />
                  <p className="text-xs">Database kosong / tidak ada invoice yang termuat.</p>
                </div>
              ) : (
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/40 text-slate-400 font-semibold uppercase text-[10px] tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="py-2.5 px-3">No. Invoice</th>
                      <th className="py-2.5 px-3">Nama Pelanggan</th>
                      <th className="py-2.5 px-3 hidden sm:table-cell">Tgl Terbit</th>
                      <th className="py-2.5 px-3">Jatuh Tempo</th>
                      <th className="py-2.5 px-3 text-right">Outstanding</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {invoices.map((inv) => {
                      const isUnpaid = inv.amountResidual > 0;
                      const isSelected = selectedInvoice?.id === inv.id;
                      return (
                        <tr
                          key={inv.id}
                          onClick={() => setSelectedInvoice(inv)}
                          className={`hover:bg-slate-800/40 transition cursor-pointer ${
                            isSelected ? 'bg-indigo-600/10 border-l-2 border-indigo-500' : ''
                          }`}
                        >
                          <td className="py-3 px-3 font-semibold text-indigo-400">{inv.number}</td>
                          <td className="py-3 px-3">
                            <div className="font-medium text-white max-w-[180px] truncate">{inv.customerName}</div>
                            {inv.customerEmail && <div className="text-[10px] text-slate-400 max-w-[180px] truncate">{inv.customerEmail}</div>}
                          </td>
                          <td className="py-3 px-3 text-slate-400 hidden sm:table-cell">{inv.date}</td>
                          <td className="py-3 px-3">
                            <div className={`${inv.daysOverdue > 0 ? 'text-rose-400 font-medium' : 'text-slate-300'}`}>
                              {inv.dueDate}
                            </div>
                            {inv.daysOverdue > 0 && <div className="text-[9px] text-rose-500 font-bold uppercase">Overdue {inv.daysOverdue}D</div>}
                          </td>
                          <td className="py-3 px-3 text-right font-bold text-slate-200">
                            {formatRupiah(inv.amountResidual)}
                            {inv.amountTotal !== inv.amountResidual && isUnpaid && (
                              <span className="block text-[9px] text-slate-400 font-normal">dari {formatRupiah(inv.amountTotal)}</span>
                            )}
                          </td>
                          <td className="py-3 px-3 text-center">
                            {inv.status === 'paid' ? (
                              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-semibold text-[10px]">Paid</span>
                            ) : inv.status === 'overdue' ? (
                              <span className="bg-rose-500/10 text-rose-400 border border-rose-500/20 px-2 py-0.5 rounded-full font-semibold text-[10px]">Overdue</span>
                            ) : (
                              <span className="bg-slate-700/20 text-slate-300 border border-slate-700/30 px-2 py-0.5 rounded-full font-semibold text-[10px]">Draft/Unpaid</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          {/* RIGHT: CHAT SIMULATOR & ACTUAL BOT LOGS (5 COLS) */}
          <div className="lg:col-span-5 flex flex-col gap-6">

            {/* SEVER PANEL: IN-APP TELEGRAM BOT EMULATOR */}
            <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-5 flex flex-col h-[520px] shadow-lg">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                <div className="flex items-center gap-2">
                  <Bot className="w-5 h-5 text-indigo-400" />
                  <div>
                    <h2 className="text-sm font-bold text-white">Simulasi Chat Bot Telegram</h2>
                    <p className="text-[10px] text-slate-400">Ketik command untuk mengetes respons instant asisten AR</p>
                  </div>
                </div>
                <span className="flex h-2.5 w-2.5 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
              </div>

              {/* CHAT BUBBLES OUTLET */}
              <div className="flex-1 overflow-y-auto bg-slate-950/60 rounded-xl p-4.5 space-y-4 shadow-inner border border-slate-800/60 custom-scrollbar text-xs">
                {botLogs.filter(log => log.type === 'incoming' || log.type === 'outgoing').length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-slate-400 py-20 space-y-2 text-center">
                    <Terminal className="w-8 h-8 text-slate-600 animate-pulse" />
                    <p className="text-xs">Uji interaksi bot asisten AR Odoo di sini!</p>
                    <p className="text-[10px] text-slate-400 max-w-[250px]">Ketik perintah asisten seperti <b>/summary</b> atau klik rekomendasi tombol di bawah.</p>
                  </div>
                ) : (
                  botLogs
                    .filter(log => log.type === 'incoming' || log.type === 'outgoing')
                    .slice()
                    .reverse()
                    .map((log) => {
                      const isUser = log.type === 'incoming';
                      return (
                        <div key={log.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[85%] rounded-2xl px-4 py-3 shadow-md ${
                            isUser 
                              ? 'bg-indigo-600 text-white rounded-br-none' 
                              : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-none'
                          }`}>
                            <div className="flex items-center gap-1.5 text-[9px] font-semibold mb-1 opacity-75 justify-between">
                              <span>{log.sender}</span>
                              <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            </div>
                            
                            {/* Message rendering with simple raw tag translation or safe break */}
                            <div className="whitespace-pre-wrap leading-relaxed select-text font-sans">
                              {/* Standard crude HTML tag parse as bot produces standard HTML response for telegram */}
                              <span dangerouslySetInnerHTML={{ __html: log.message }}></span>
                            </div>
                          </div>
                        </div>
                      );
                    })
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Bot Prompt quick suggestion chips */}
              <div className="flex flex-wrap gap-1.5 py-3 border-t border-slate-800/40 mt-1">
                <button
                  type="button"
                  onClick={() => { setChatMessage('/start') }}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded text-[10px] font-medium"
                >
                  /start
                </button>
                <button
                  type="button"
                  onClick={() => { setChatMessage('/summary') }}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded text-[10px] font-medium"
                >
                  /summary
                </button>
                <button
                  type="button"
                  onClick={() => { setChatMessage('/outstanding') }}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded text-[10px] font-medium"
                >
                  /outstanding
                </button>
                <button
                  type="button"
                  onClick={() => { setChatMessage('/overdue') }}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded text-[10px] font-medium"
                >
                  /overdue
                </button>
                <button
                  type="button"
                  onClick={() => { setChatMessage('/aging') }}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded text-[10px] font-medium"
                >
                  /aging
                </button>
                <button
                  type="button"
                  onClick={() => { setChatMessage('/customer') }}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2 py-1 rounded text-[10px] font-medium"
                >
                  /customer
                </button>
              </div>

              {/* FORM SUBMISSION FOR CHAT */}
              <form onSubmit={handleSendChatMessage} className="flex gap-2">
                <input
                  type="text"
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  placeholder="Ketik command telegram, e.g. /remind CV Sumber..."
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 shadow-inner"
                  disabled={isChatSending}
                />
                <button
                  type="submit"
                  disabled={isChatSending || !chatMessage.trim()}
                  className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-45 text-white p-3 rounded-xl transition shadow-lg shadow-indigo-600/20 flex items-center justify-center shrink-0 cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>

            {/* BOT ACTIVITY TRACE STATUS (REAL LOGGER LOGGER) */}
            <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-5 flex flex-col shadow-lg space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4.5 h-4.5 text-indigo-400" />
                  <h3 className="text-sm font-bold text-white">Log Aktivitas Server Bot</h3>
                </div>
                <button
                  onClick={clearLogs}
                  className="text-[10px] text-rose-400 hover:underline hover:text-rose-300 bg-none cursor-pointer"
                >
                  Clear Logs
                </button>
              </div>

              {/* Log List Output */}
              <div className="bg-slate-950 rounded-xl p-3 h-48 overflow-y-auto space-y-2.5 font-mono text-[10px] text-slate-400 border border-slate-800">
                {botLogs.length === 0 ? (
                  <p className="text-slate-600 py-10 text-center italic">Tidak ada log aktivitas.</p>
                ) : (
                  botLogs.map((log) => {
                    let typeBadge = '';
                    if (log.type === 'incoming') typeBadge = '[RECV]';
                    else if (log.type === 'outgoing') typeBadge = '[SEND]';
                    else if (log.type === 'system') typeBadge = '[SYST]';
                    else typeBadge = '[ERR!]';

                    const color = log.type === 'incoming' 
                      ? 'text-indigo-400' 
                      : log.type === 'outgoing' 
                        ? 'text-emerald-400' 
                        : log.type === 'system'
                          ? 'text-sky-400'
                          : 'text-rose-400';

                    return (
                      <div key={log.id} className="border-b border-slate-900 pb-1.5 last:border-0">
                        <div className="flex justify-between items-center text-[9px] text-slate-500 mb-0.5">
                          <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                          <span className={`${color} font-bold`}>{typeBadge}</span>
                        </div>
                        <p className="text-slate-100">{log.message}</p>
                        {log.details && <p className="text-[9px] text-slate-500 mt-0.5">{log.details}</p>}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

          </div>
        </section>

        {/* BOTTOM FULL-WIDTH: GEMINI AI AR REMINDER DRAFT GENERATOR */}
        <section className="bg-slate-900/40 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 p-12 w-96 h-96 bg-indigo-500/5 rounded-full filter blur-3xl pointer-events-none"></div>

          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-5">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl border border-indigo-500/20">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h2 className="text-base font-bold text-white">Gemini AI AR Billing Remind Draft</h2>
                <p className="text-xs text-slate-400">Pilih salah satu invoice di tabel atas untuk membuat draf WhatsApp pengingat otomatis oleh AI</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs text-slate-400">Gaya Bahasa:</span>
              <select
                value={draftTone}
                onChange={(e) => setDraftTone(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500 font-medium"
              >
                <option value="Sopan, Ramah, & Profesional">Sopan, Ramah, & Profesional</option>
                <option value="Tegas namun sopan (Lewat Jatuh Tempo &gt; 30 hari)">Tegas namun sopan (Overdue lama)</option>
                <option value="Sangat Kasual (Untuk Partner Akrab/UMKM kecil)">Sangat Kasual (Mitra Akrab)</option>
                <option value="Bahasa Inggris Formal (Internasional)">English Formal (International)</option>
              </select>

              <button
                onClick={generateAIDraft}
                disabled={isGeneratingDraft || !selectedInvoice}
                className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-bold text-xs px-4 py-2 rounded-lg transition shadow-lg shadow-indigo-600/20 flex items-center gap-1.5 shrink-0 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingDraft ? 'animate-spin' : ''}`} />
                Jadikan Ulang Draf AI
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            {/* Meta client profile details */}
            <div className="md:col-span-4 bg-slate-950/60 rounded-xl p-5 border border-slate-800 space-y-4">
              <span className="text-xs font-semibold text-white block border-b border-slate-800 pb-2">Data Pelanggan Terpilih</span>
              {selectedInvoice ? (
                <div className="space-y-3.5 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-medium">Mitra Bisnis</span>
                    <p className="text-white font-bold text-sm leading-tight flex items-center gap-1.5 mt-0.5">
                      <User className="w-4 h-4 text-indigo-400" />
                      {selectedInvoice.customerName}
                    </p>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-500 block uppercase font-medium">No. Invoice Aktif</span>
                    <p className="text-indigo-400 font-semibold mt-0.5">{selectedInvoice.number}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-medium">Tgl Tagihan</span>
                      <p className="text-slate-300 mt-0.5">{selectedInvoice.date}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase font-medium">Jatuh Tempo</span>
                      <p className="text-slate-300 mt-0.5">{selectedInvoice.dueDate}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <span className="text-[10px] text-slate-500 block uppercase">Outs. Amount</span>
                      <p className="text-white font-bold mt-0.5">{formatRupiah(selectedInvoice.amountResidual)}</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-rose-500 block uppercase font-bold">Keterlambatan</span>
                      <p className="text-rose-400 font-bold mt-0.5">{selectedInvoice.daysOverdue > 0 ? `${selectedInvoice.daysOverdue} Hari` : 'Tidak Terlambat'}</p>
                    </div>
                  </div>

                  <div className="bg-indigo-500/5 p-3 rounded-lg border border-indigo-500/10 text-[11px] text-slate-300">
                    💡 <b>Aturan Penagihan Otomatis:</b> Gemini akan mengompilasi seluruh invoice yang berstatus unpaid milik customer <b>{selectedInvoice.customerName}</b> untuk dicantumkan sekaligus ke draf pesan WhatsApp.
                  </div>
                </div>
              ) : (
                <div className="py-8 text-center text-slate-500 italic text-xs">
                  Silakan pilih salah satu baris invoice di tabel sebelah kiri untuk menilai data & draf pesan.
                </div>
              )}
            </div>

            {/* DRAFT OUTPUT TEXT AREA WITH COPY TO CLIPBOARD */}
            <div className="md:col-span-8 flex flex-col space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-white flex items-center gap-1">
                  <CreditCard className="w-4 h-4 text-indigo-400" />
                  Draf Siap Kirim (Copy & Paste ke WhatsApp/Telegram)
                </span>
                {generatedDraft && (
                  <button
                    onClick={copyToClipboard}
                    className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-100 px-3.5 py-1.5 rounded-lg font-medium border border-slate-700 inline-flex items-center gap-1.5 transition cursor-pointer"
                  >
                    {copiedDraft ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    {copiedDraft ? 'Tersalin' : 'Salin Draf'}
                  </button>
                )}
              </div>

              <div className="flex-1 relative">
                {isGeneratingDraft ? (
                  <div className="w-full h-80 bg-slate-950/80 rounded-xl flex flex-col items-center justify-center space-y-2 border border-slate-800">
                    <Sparkles className="w-8 h-8 text-indigo-500 animate-pulse" />
                    <p className="text-xs text-slate-400">Gemini AI sedang menyusun draf pesan penagihan ({draftTone})...</p>
                  </div>
                ) : (
                  <textarea
                    readOnly
                    value={generatedDraft}
                    className="w-full h-80 bg-slate-950 font-mono text-xs p-4.5 rounded-xl border border-slate-800 leading-relaxed text-slate-200 focus:outline-none resize-none shadow-inner"
                    placeholder="Pilih item invoice untuk merangkum draf prompt di sini."
                  />
                )}
              </div>
            </div>
          </div>
        </section>

        {/* BOTTOM COMMAND REFERENCE EXPLANATION (Indonesian Localized Reference for AR Bot) */}
        <section className="bg-slate-900/20 border border-slate-800/80 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-2.5">
            <HelpCircle className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-bold text-white">Panduan Struktur & Ide Penagihan AR dengan Telegram Bot</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-300">
            <div className="space-y-2">
              <h4 className="font-bold text-indigo-400">1. Kenapa Menggunakan Telegram?</h4>
              <p className="leading-relaxed">
                Staff AR membutuhkan info cepat tanpa perlu login ke dashboard Odoo yang berat di mobile. Lewat bot Telegram ini, staff AR di lapangan atau direksi perusahaan dapat mengetik /outstanding atau /summary langsung dari HP secara realtime untuk memantau piutang.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-bold text-indigo-400">2. Apa saja yang dibutuhkan?</h4>
              <p className="leading-relaxed">
                Anda sudah memiliki Bot Token (dari @BotFather) & Chat ID Anda. Untuk operasional riil, Anda hanya memerlukan <b>Odoo ERP URL, Nama Database, Username</b>, dan <b>Web API developer key (atau password)</b> yang dimasukkan lewat tombol Konfigurasi di atas.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-bold text-indigo-400">3. Cara Kerja Webhook Autentikasi</h4>
              <p className="leading-relaxed">
                Saat Anda klik <b>Daftarkan Webhook</b>, server kami mendaftarkan URL HTTPS internal kami ke Telegram API. Setiap kali Anda mengirim pesan ke bot asisten Anda di HP, Telegram meneruskannya ke server Express ini, melakukan query ke Odoo, memproses draf lewat Gemini AI, dan mengirimkan balik laporannya ke chat room Anda.
              </p>
            </div>
          </div>

          <div className="pt-4 mt-2 border-t border-slate-800/50">
            <h4 className="text-xs font-bold text-white mb-2.5">Daftar Perintah (Commands) Bot yang Didukung:</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
              {commands.map((cmd, idx) => (
                <div key={idx} className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-indigo-400 text-xs font-mono">{cmd.command}</span>
                    <span className="text-[9px] text-slate-400 font-medium px-2 py-0.5 bg-slate-900 border border-slate-800 rounded">Command</span>
                  </div>
                  <p className="text-[11px] text-slate-300 font-medium">{cmd.description}</p>
                  <p className="text-[10px] text-slate-500 leading-tight">Guna: {cmd.useCase}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

      </main>

      <footer className="border-t border-slate-800/40 bg-slate-900/20 text-center py-6 text-xs text-slate-500 relative z-10">
        <p>© 2026 Odoo ERP accounts receivable Telegram Integration Control Center. Built with Google Gemini AI Studio.</p>
        <p className="text-[10px] text-slate-600 mt-1">Menggunakan standard @google/genai TypeScript SDK</p>
      </footer>
    </div>
  );
}
